var likes = 9
var countLikes = document.querySelector("#likes") //this likes the function to the html one

console.log(countLikes)
function moreLikes() {
    likes++;
    countLikes.innerText = likes + ' like(s)'; //this counts the number of likes and adds 1 to it on each click
    // console.log(likes); my own personal check
}

var likes1 = 12
var countLikes1 = document.querySelector("#likes1") //this likes the function to the html one

console.log(countLikes1)
function moreLikes2() {
    likes1++;
    countLikes1.innerText = likes1 + ' like(s)'; //this counts the number of likes and adds 1 to it on each click
    // console.log(likes); my own personal check
}

var likes3 = 9
var countLikes2 = document.querySelector("#likes2") //this likes the function to the html one

console.log(countLikes)
function moreLikes3() {
    likes3++;
    countLikes2.innerText = likes3 + ' like(s)'; //this counts the number of likes and adds 1 to it on each click
    //     // console.log(likes); my own personal check
}
